#ifndef _CONFIG_COM_H_
#define _CONFIG_COM_H_

#include <config.h>

#define NUM_ATTEMPTS 10

#include <ardrone_tool/Com/config_serial.h>

#include <ardrone_tool/Com/config_wifi.h>

#endif // _CONFIG_COM_H_
