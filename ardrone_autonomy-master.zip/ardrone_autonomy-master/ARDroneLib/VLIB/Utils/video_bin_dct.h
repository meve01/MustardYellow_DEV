#ifndef _VIDEO_BIN_DCT_H_
#define _VIDEO_BIN_DCT_H_

#include <VLIB/video_dct.h>

// Alternative DCT computation

#endif // _VIDEO_BIN_DCT_H_
